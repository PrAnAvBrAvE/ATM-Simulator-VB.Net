# ATM-simulator-using-VB-.Net
I have created ATM management System using VB .Net. I have used visual studio software. I have used MS-Access database for storing details. I have provided two logins one for user where he/she can login and perform operations such as deposit, withdraw, transfer and view account balance. The second login I have provided for admin where admin can see user details, update user details, search details, block and unblock user accounts.<br/>
Click on image to watch on youtube.<br/>
[![Watch the video](https://img.youtube.com/vi/r2zA00K1f_s/maxresdefault.jpg)](https://youtu.be/r2zA00K1f_s)</center> 


